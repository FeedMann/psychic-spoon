# Shells & Watermelon Temp-Entity Lab — integration guide

This package is a **visual temporary-entity system** modeled on the lightweight HL1/Source approach. It is not a rigid-body gameplay physics implementation and it is not a VPhysics replacement.

The included web viewer runs the complete effect simulation in `temp_gibs.cpp`, compiled to `temp_gibs.wasm`. The browser code only drives controls, moves the source through exported wasm functions, reads the exported Structure-of-Arrays memory, and draws it.

---

## 1. What the sample is demonstrating

The system has two C++-owned effects:

| Effect | Spawn pattern | Visual payload |
|---|---|---|
| Shell ejector | Continuous, staggered spawning from one movable source | Brass casing variants |
| Watermelon burst | One-shot explosion from the current source location | Rind, pulp, and seed chunks |

Each active temp entity has contiguous arrays for its position, velocity, angle, angular velocity, lifetime, active flag, and visual kind. This **Structure of Arrays** layout means the hot update loop walks linear memory rather than chasing thousands of separate game objects.

For a real game, the `kind` value normally selects an actual shell model, gib model, decal/material, particle, sound, or a small render proxy. In this Canvas demonstration it selects a painted casing/rind/pulp/seed shape.

---

## 2. Update loop: what actually happens

The core update in `temp_gibs.cpp` deliberately follows the legacy temp-entity pattern:

```text
for each active temporary entity:
    position += velocity * dt
    resolve world-bound and map-wall contacts
    if an incoming contact occurred:
        velocity = reflect(velocity, collisionNormal) * bounceDamping
        angularVelocity *= spinDamping
    apply gravity
    integrate angle
    decrement lifetime
    recycle/disable if lifetime expired
```

The wasm sample uses two substeps per browser frame. It limits the frame time and splits it into two smaller updates. That is a cheap way to reduce obvious tunnelling without implementing a full rigid-body solver.

### Reflection

For a collision normal `n` and incoming velocity `v`, the reflected velocity is:

```text
v_reflected = v - 2 * dot(v, n) * n
v_after = v_reflected * bounceDamping
```

The sample only reflects if `dot(v, n) < 0`, meaning the entity is moving into that face. `bounceDamping` removes energy after each hit, preventing an endlessly bouncing casing.

### Resting on the floor

Small floor impacts use a deliberately cheap “rest” test:

- if downward speed is still substantial, bounce normally;
- otherwise, zero vertical velocity;
- damp horizontal slide;
- zero angular velocity so a casing or fruit fragment that has settled does **not** spin forever.

This is a visual-effect stability rule, not an attempt to solve static friction and angular momentum physically.

---

## 3. How the sample collides with the world

The web map consists of a floor, world limits, and static vertical AABB wall volumes:

```cpp
struct Wall {
    float minX, maxX;
    float minY, maxY;
    float height;
};
```

For each wall, a temp entity only needs a collision test while it is below that wall’s height. The wall is expanded by the small debris radius, then the entity is tested against the expanded rectangle in XY. If it is inside, the closest wall face is chosen:

```text
left distance, right distance, bottom distance, top distance
→ choose the smallest
→ move entity outside that face
→ use that face normal for reflection
```

Floor/ceiling/world-border contacts are handled in the same update pass.

### Why use this method here?

It has properties that matter for cosmetic debris:

- **Cheap:** A few arithmetic operations per wall, no per-entity physics object allocation.
- **Predictable:** No solver iteration count, joint graph, or contact manifold changes.
- **Scales well:** Hundreds or thousands of short-lived visual items can update client-side.
- **Easy to recycle:** A slot can be reactivated without creating/destroying a full engine entity.
- **Sufficient for the goal:** Shells and fruit chunks need to read as bouncing off the world; they usually do not need physically accurate pile-up behavior.

### Why not VPhysics / a normal rigid-body solver?

A rigid-body solver earns its cost when gameplay needs any of the following:

- object-to-object collision and stacking;
- meaningful mass, inertia, friction, torque, or joints;
- players pushing/picking up an object;
- server-authoritative interaction;
- persistent props whose state must replicate or save.

For 2,000 cosmetic casings, every one of those needs would make the effect much more expensive and more network-sensitive. A pile of visible temp shells does **not** normally need to be 2,000 gameplay entities.

### Limitations of this exact web collision

The demo uses point-vs-expanded-AABB resolution, so it is intentionally limited:

- no debris-vs-debris collision;
- no slopes, triangle meshes, or curved surfaces;
- no moving/rotating prop contacts;
- extreme velocity can still tunnel through thin geometry despite the two substeps;
- a corner is resolved against one nearest face rather than a complete contact manifold.

Those trade-offs are appropriate for a self-contained browser lab, not necessarily for a shipped map collision implementation.

---

## 4. Real-game collision: replace the demo wall test, keep the effect model

In a real Source-like game, retain the SoA pool, lifetime, reflection/damping, and client-only rendering. Replace `ResolveWall()` with the engine’s **world trace/hull trace**.

The conceptual version is:

```cpp
Vector oldPosition = position[i];
Vector requestedPosition = oldPosition + velocity[i] * dt;

TraceResult hit = TraceSphereOrHullAgainstWorld(
    oldPosition,
    requestedPosition,
    kShellRadius,
    MASK_SOLID_BRUSHONLY // or the project’s appropriate cosmetic-world mask
);

if (hit.didHit) {
    position[i] = hit.endPosition + hit.normal * kContactPushOut;

    if (Dot(velocity[i], hit.normal) < 0.0f) {
        velocity[i] = Reflect(velocity[i], hit.normal) * bounce;
        angularVelocity[i] *= spinDamping;
    }

    if (hit.normal.z > kFloorNormalThreshold &&
        Abs(velocity[i].z) < kRestSpeed) {
        velocity[i].z = 0.0f;
        angularVelocity[i] = 0.0f;
    }
} else {
    position[i] = requestedPosition;
}
```

Use a **ray trace** for tiny, fast, non-important visual bits if that is enough. Use a small **sphere/hull sweep** for shell casings or larger gib pieces so they do not visually enter a wall before the collision. The key point is that you trace the game’s actual static collision world, then apply the same lightweight response yourself—rather than allocating a full rigid body per casing.

For a Source-derived codebase, the exact trace API and collision mask names differ by branch. Typical concepts are a `Ray_t`/swept box or an engine trace helper, a `trace_t`/game-trace result, an end position, plane normal, fraction, and a content/collision mask. Use your branch’s existing client temp-entity or client-effect tracing conventions as the compatibility reference.

---

## 5. Attaching an emitter to a weapon, character, or moving prop

An attachment is a named transform on a model/skeleton: for example a weapon’s `shell_eject`, `eject`, or `muzzle` attachment. Every render/update frame the engine can resolve it into a world-space position and orientation.

### Important rule: attach the **source**, not every emitted casing

1. Find the current attachment transform.
2. Update the effect emitter to that transform.
3. Spawn **new** casings at the current transform.
4. Once a casing exists, it owns independent position/velocity/spin state and continues flying in world space.

Do **not** keep old casings parented to the gun attachment. They should be left behind in the world once ejected.

### Generic integration pseudocode

```cpp
// Called while a weapon exists and is being presented on the local client.
AttachmentTransform eject = weapon.GetAttachmentTransform("shell_eject");

shellEffect.SetEmitterTransform(
    eject.position,
    eject.forward,
    eject.right,
    eject.up
);

if (weaponJustFired || weaponJustReloaded) {
    shellEffect.EmitShells(1); // or schedule a short burst
}
```

The present web module exposes position only:

```cpp
wasm.set_emitter(x, y, z);
```

For production, extend it from a point to a basis/orientation. Store an `emitterForward`, `emitterRight`, and `emitterUp` vector (or a quaternion) alongside the emitter position. Then form launch velocity in attachment-local space:

```cpp
// Numbers are illustrative, not engine units.
Vector localVelocity(
    RandomRange(2.0f, 8.0f),    // forward
    RandomRange(10.0f, 18.0f),  // outward/right: the actual ejection direction
    RandomRange(3.0f, 10.0f)    // upward
);

velocity[i] = attachmentForward * localVelocity.x
            + attachmentRight   * localVelocity.y
            + attachmentUp      * localVelocity.z;
position[i] = attachmentPosition + attachmentRight * smallOffset;
```

That is the missing step that makes a casing leave the correct side of a rotating weapon instead of using a fixed world-space direction.

### Watermelon / breakable attachment case

For a watermelon prop, the source transform is simply the prop’s current center or hit point. On a break event:

```cpp
watermelonEffect.SetEmitterTransform(hitPosition, propOrientation);
watermelonEffect.Explode(seed, fragmentCount);
```

If the watermelon is moving, optionally add the prop’s current linear velocity to each fragment’s initial velocity. This makes the pieces inherit the motion of the object that exploded.

---

## 6. Client/server ownership and networking

For cosmetic shell ejection and decorative fruit chunks:

- Simulate locally on the client.
- Do not make every casing a replicated server entity.
- The local player may emit immediately from predicted weapon state for responsiveness.
- Other clients can receive a small event: effect ID, world/attachment transform, seed, count, and initial velocity multiplier.

One small deterministic event can reproduce a similar burst on every relevant client. Sending 2,000 position updates would be wasteful and still does not make the result gameplay-authoritative.

If a fragment must damage players, block movement, be picked up, or affect scoring, that gameplay object belongs on the server and should use the project’s authoritative physics/gameplay rules. You can still add a separate client-only cosmetic burst around it.

---

## 7. Practical tuning guide

| Symptom | Primary change |
|---|---|
| Casings pass through thin walls | More substeps, a swept hull trace, or clamp maximum speed |
| Casings bounce too long | Reduce `bounceDamping` |
| Casings look dead on impact | Increase bounce slightly, or increase ejection speed |
| Casings spin while apparently settled | Increase rest threshold or zero angular velocity in the floor-rest path |
| Effect costs too much | Reduce active slot count, trace every other frame for distant fragments, cull by distance/visibility, use a shorter lifetime |
| Watermelon burst looks too uniform | Vary fragment shape/model, add inherited prop velocity, bias some chunks upward, randomize lifetime and launch speed |

---

## 8. File map

```text
index.html              Page layout and controls
app.js                  UI, orbit camera, input forwarding, Canvas renderer
temp_gibs.cpp           Actual C++ simulation and wasm exports
temp_gibs.wasm          Prebuilt module for the viewer
build.sh                Rebuilds the wasm module using freestanding Clang
README.md               Quick-start build/run instructions
INTEGRATION_GUIDE.md    This document
```

The project is intentionally self-contained: no external package manager, renderer library, game engine, or web CDN is required to run the browser showcase.
