// Temp Gibs Lab — a small, self-contained C++ / WebAssembly simulation.
//
// It deliberately follows the old HL1/Source temporary-entity pattern:
//    position += velocity * dt
//    trace / resolve against world geometry
//    reflect velocity around collision normal
//    damp the velocity
//    apply gravity, spin, lifetime, and recycle
//
// Unlike VPhysics this has no rigid-body solver, no mass pairs, no joints and
// no server authority. It is a client-side SoA effect simulation.

#include <stdint.h>

namespace {

constexpr int kMaxTempEntities = 4096;
constexpr int kWallCount = 8;
constexpr float kRadius = 0.23f;
constexpr float kWorldLeft = -32.0f;
constexpr float kWorldRight = 32.0f;
constexpr float kWorldBottom = -20.0f;
constexpr float kWorldTop = 20.0f;
constexpr float kFloor = 0.0f;
constexpr float kCeiling = 16.0f;

// Structure of Arrays: contiguous values of each attribute, rather than
// `struct TempEnt { ... } tempents[N]`. This is cache/SIMD-friendly and maps
// directly to typed-array views in JavaScript.
alignas(16) float g_px[kMaxTempEntities];
alignas(16) float g_py[kMaxTempEntities];
alignas(16) float g_pz[kMaxTempEntities];
alignas(16) float g_vx[kMaxTempEntities];
alignas(16) float g_vy[kMaxTempEntities];
alignas(16) float g_vz[kMaxTempEntities];
alignas(16) float g_spin[kMaxTempEntities];
alignas(16) float g_spinVelocity[kMaxTempEntities];
alignas(16) float g_life[kMaxTempEntities];
alignas(16) float g_emitDelay[kMaxTempEntities];
alignas(16) uint32_t g_active[kMaxTempEntities];
alignas(16) uint32_t g_kind[kMaxTempEntities];

struct Wall {
    float minX, maxX;
    float minY, maxY;
    float height;
};

// A tiny top-down "test map": outer bounds plus interior walls/pillars.
const Wall kWalls[kWallCount] = {
    {-14.0f, -13.0f, -20.0f,  7.5f, 12.0f},
    {-14.0f,  -4.0f,  7.5f,  8.5f, 12.0f},
    {  4.0f,   5.0f, -8.5f, 20.0f, 12.0f},
    {  5.0f,  15.0f, -8.5f, -7.5f, 12.0f},
    {-25.0f, -20.0f, -12.0f, -7.0f,  8.0f},
    { 20.0f,  25.0f,  8.0f, 13.0f,  8.0f},
    {-2.0f,   2.0f,  -2.0f,  2.0f, 16.0f},
    { 13.0f, 16.0f, -16.0f,-13.0f,  8.0f},
};

int g_count = 2000;
float g_gravity = 22.0f;
float g_bounce = 0.52f;
// The emitter is C++ state as well. Browser input may request a new location,
// but spawn code reads these values directly from the wasm simulation.
float g_emitterX = -8.5f;
float g_emitterY = -12.0f;
float g_emitterZ = 5.5f;
uint32_t g_rng = 0xC0FFEE11u;
uint32_t g_collisionCount = 0;
uint32_t g_recycledCount = 0;
// 0: continuous brass-shell ejector; 1: one-shot watermelon fragment burst.
int g_effectMode = 0;

inline float absf(float value) { return value < 0.0f ? -value : value; }
inline float minf(float a, float b) { return a < b ? a : b; }

uint32_t NextRandom() {
    // xorshift32: fast and deterministic, appropriate for visual debris.
    uint32_t value = g_rng;
    value ^= value << 13;
    value ^= value >> 17;
    value ^= value << 5;
    g_rng = value;
    return value;
}

float Random01() {
    return static_cast<float>(NextRandom() & 0x00FFFFFFu) * (1.0f / 16777216.0f);
}

float RandomRange(float low, float high) {
    return low + (high - low) * Random01();
}

void Spawn(int index) {
    // One visible cartridge-ejector/emitter. Scheduled slot activation and
    // lifetime recycling make this a genuine continuous emitter rather than
    // a pre-scattered field of objects.
    g_px[index] = g_emitterX + RandomRange(-0.42f, 0.42f);
    g_py[index] = g_emitterY + RandomRange(-0.42f, 0.42f);
    g_pz[index] = g_emitterZ + RandomRange(-0.36f, 0.36f);

    // The ejection cone sweeps through the room rather than throwing a
    // radial particle explosion. It is meant to read as shell casings leaving
    // a Garry's Mod-style temp-entity emitter.
    g_vx[index] = RandomRange(2.5f, 13.5f) + RandomRange(-2.0f, 2.0f);
    g_vy[index] = RandomRange(8.5f, 20.0f) + RandomRange(-2.8f, 2.8f);
    g_vz[index] = RandomRange(4.0f, 17.0f);
    g_spin[index] = RandomRange(0.0f, 6.2831853f);
    g_spinVelocity[index] = RandomRange(-19.0f, 19.0f);
    g_life[index] = RandomRange(3.2f, 8.5f);
    g_kind[index] = NextRandom() % 3u; // brass-shell shape/color variant
}

void SpawnWatermelonFragment(int index) {
    // One burst reuses the same cheap temp-entity loop, but swaps the shell
    // ejection cone for a roughly spherical, upward-biased fruit explosion.
    g_px[index] = g_emitterX + RandomRange(-0.32f, 0.32f);
    g_py[index] = g_emitterY + RandomRange(-0.32f, 0.32f);
    g_pz[index] = g_emitterZ + RandomRange(-0.32f, 0.32f);
    // Independent horizontal components make a cheap radial-ish cloud without
    // pulling a heavyweight math library into the freestanding wasm module.
    g_vx[index] = RandomRange(-16.0f, 16.0f);
    g_vy[index] = RandomRange(-16.0f, 16.0f);
    g_vz[index] = RandomRange(2.0f, 17.0f);
    g_spin[index] = RandomRange(0.0f, 6.2831853f);
    g_spinVelocity[index] = RandomRange(-23.0f, 23.0f);
    g_life[index] = RandomRange(2.4f, 6.8f);
    // 3 rind, 4 pulp, 5 seed: the renderer interprets these as fruit chunks.
    const uint32_t roll = NextRandom() % 10u;
    g_kind[index] = roll < 3u ? 3u : (roll < 8u ? 4u : 5u);
}

void Reflect(int index, float nx, float ny, float nz, float damping) {
    float dot = g_vx[index] * nx + g_vy[index] * ny + g_vz[index] * nz;
    if (dot < 0.0f) {
        // v' = v - 2 * dot(v,n) * n; then apply a fake bounce damping.
        g_vx[index] = (g_vx[index] - 2.0f * dot * nx) * damping;
        g_vy[index] = (g_vy[index] - 2.0f * dot * ny) * damping;
        g_vz[index] = (g_vz[index] - 2.0f * dot * nz) * damping;
        g_spinVelocity[index] *= 0.89f;
        ++g_collisionCount;
    }
}

void ResolveWorldBounds(int index) {
    if (g_px[index] < kWorldLeft + kRadius) {
        g_px[index] = kWorldLeft + kRadius;
        Reflect(index, 1.0f, 0.0f, 0.0f, g_bounce);
    } else if (g_px[index] > kWorldRight - kRadius) {
        g_px[index] = kWorldRight - kRadius;
        Reflect(index, -1.0f, 0.0f, 0.0f, g_bounce);
    }

    if (g_py[index] < kWorldBottom + kRadius) {
        g_py[index] = kWorldBottom + kRadius;
        Reflect(index, 0.0f, 1.0f, 0.0f, g_bounce);
    } else if (g_py[index] > kWorldTop - kRadius) {
        g_py[index] = kWorldTop - kRadius;
        Reflect(index, 0.0f, -1.0f, 0.0f, g_bounce);
    }

    if (g_pz[index] < kFloor + kRadius) {
        g_pz[index] = kFloor + kRadius;
        // HL-style cheap rest test: do not count a stationary shell as a new
        // impact every frame merely because gravity was applied again.
        if (g_vz[index] < -0.85f) {
            Reflect(index, 0.0f, 0.0f, 1.0f, g_bounce);
        } else {
            g_vz[index] = 0.0f;
            g_vx[index] *= 0.94f;
            g_vy[index] *= 0.94f;
            // Legacy effects normally cease rotation when they settle. That
            // avoids a shell that looks frozen on the floor but spins forever.
            g_spinVelocity[index] = 0.0f;
            if (absf(g_vx[index]) + absf(g_vy[index]) < 0.18f) {
                g_vx[index] = 0.0f;
                g_vy[index] = 0.0f;
            }
        }
    } else if (g_pz[index] > kCeiling - kRadius) {
        g_pz[index] = kCeiling - kRadius;
        Reflect(index, 0.0f, 0.0f, -1.0f, g_bounce);
    }
}

void ResolveWall(int index, const Wall& wall) {
    if (g_pz[index] > wall.height + kRadius) return;

    const float left = wall.minX - kRadius;
    const float right = wall.maxX + kRadius;
    const float bottom = wall.minY - kRadius;
    const float top = wall.maxY + kRadius;

    if (g_px[index] <= left || g_px[index] >= right ||
        g_py[index] <= bottom || g_py[index] >= top) {
        return;
    }

    // A cheap point-vs-expanded-AABB collision. Choose the closest face,
    // move outside, and use that face normal for an HL-style bounce.
    const float toLeft = g_px[index] - left;
    const float toRight = right - g_px[index];
    const float toBottom = g_py[index] - bottom;
    const float toTop = top - g_py[index];

    float best = toLeft;
    int face = 0;
    if (toRight < best) { best = toRight; face = 1; }
    if (toBottom < best) { best = toBottom; face = 2; }
    if (toTop < best) { best = toTop; face = 3; }

    if (face == 0) {
        g_px[index] = left;
        Reflect(index, -1.0f, 0.0f, 0.0f, g_bounce);
    } else if (face == 1) {
        g_px[index] = right;
        Reflect(index, 1.0f, 0.0f, 0.0f, g_bounce);
    } else if (face == 2) {
        g_py[index] = bottom;
        Reflect(index, 0.0f, -1.0f, 0.0f, g_bounce);
    } else {
        g_py[index] = top;
        Reflect(index, 0.0f, 1.0f, 0.0f, g_bounce);
    }
}

void IntegrateOne(int index, float dt) {
    // The legacy temp-entity order is intentionally familiar:
    // move, trace/resolve, then apply gravity if no special rigid-body solver.
    g_px[index] += g_vx[index] * dt;
    g_py[index] += g_vy[index] * dt;
    g_pz[index] += g_vz[index] * dt;

    ResolveWorldBounds(index);
    for (int wall = 0; wall < kWallCount; ++wall) {
        ResolveWall(index, kWalls[wall]);
    }

    g_vz[index] -= g_gravity * dt;
    g_spin[index] += g_spinVelocity[index] * dt;
    g_life[index] -= dt;

    if (g_life[index] <= 0.0f) {
        // Recycling does not teleport a visible shell. It returns the slot to
        // the emitter scheduler, which gives the next casing a brief gap.
        g_active[index] = 0u;
        g_emitDelay[index] = RandomRange(0.025f, 0.16f);
        ++g_recycledCount;
    }
}

} // namespace

#define WASM_EXPORT extern "C" __attribute__((visibility("default")))

WASM_EXPORT void reset(uint32_t seed, int count) {
    g_rng = seed ? seed : 0xC0FFEE11u;
    g_count = count < 1 ? 1 : (count > kMaxTempEntities ? kMaxTempEntities : count);
    g_effectMode = 0;
    g_collisionCount = 0;
    g_recycledCount = 0;
    for (int i = 0; i < g_count; ++i) {
        // Stagger initial activation so the scene visibly starts emitting
        // shells from one point instead of materializing 2,000 at once.
        g_active[i] = 0u;
        g_emitDelay[i] = (i % 40 == 0) ? 0.0f : RandomRange(0.0f, 1.55f);
    }
}

WASM_EXPORT void step(float dt) {
    // Fixed substeps reduce tunneling without turning this into VPhysics.
    if (dt < 0.0f) return;
    if (dt > 0.05f) dt = 0.05f;
    const int substeps = 2;
    const float h = dt / static_cast<float>(substeps);
    for (int substep = 0; substep < substeps; ++substep) {
        for (int i = 0; i < g_count; ++i) {
            if (g_active[i]) {
                IntegrateOne(i, h);
            } else if (g_effectMode == 0) {
                g_emitDelay[i] -= h;
                if (g_emitDelay[i] <= 0.0f) {
                    Spawn(i);
                    g_active[i] = 1u;
                }
            }
        }
    }
}

WASM_EXPORT void set_gravity(float gravity) {
    g_gravity = gravity < 0.0f ? 0.0f : (gravity > 60.0f ? 60.0f : gravity);
}

WASM_EXPORT void set_bounce(float bounce) {
    g_bounce = bounce < 0.05f ? 0.05f : (bounce > 0.95f ? 0.95f : bounce);
}

WASM_EXPORT void set_emitter(float x, float y, float z) {
    // Keep the marker and source inside the visible test chamber. This is an
    // emitter placement bound, not a physical constraint on spawned shells.
    g_emitterX = x < -30.0f ? -30.0f : (x > 30.0f ? 30.0f : x);
    g_emitterY = y < -18.0f ? -18.0f : (y > 18.0f ? 18.0f : y);
    g_emitterZ = z < 0.6f ? 0.6f : (z > 14.5f ? 14.5f : z);
}

WASM_EXPORT float emitter_x() { return g_emitterX; }
WASM_EXPORT float emitter_y() { return g_emitterY; }
WASM_EXPORT float emitter_z() { return g_emitterZ; }

WASM_EXPORT void explode_watermelon() {
    g_effectMode = 1;
    g_collisionCount = 0;
    g_recycledCount = 0;
    for (int i = 0; i < g_count; ++i) {
        SpawnWatermelonFragment(i);
        g_active[i] = 1u;
    }
}

WASM_EXPORT int entity_count() { return g_count; }
WASM_EXPORT uint32_t collision_count() { return g_collisionCount; }
WASM_EXPORT uint32_t recycled_count() { return g_recycledCount; }
WASM_EXPORT int max_entities() { return kMaxTempEntities; }
WASM_EXPORT int wall_count() { return kWallCount; }

WASM_EXPORT const float* positions_x() { return g_px; }
WASM_EXPORT const float* positions_y() { return g_py; }
WASM_EXPORT const float* positions_z() { return g_pz; }
WASM_EXPORT const float* velocities_x() { return g_vx; }
WASM_EXPORT const float* velocities_y() { return g_vy; }
WASM_EXPORT const float* spins() { return g_spin; }
WASM_EXPORT const uint32_t* active() { return g_active; }
WASM_EXPORT const uint32_t* kinds() { return g_kind; }
WASM_EXPORT const Wall* wall_data() { return kWalls; }
