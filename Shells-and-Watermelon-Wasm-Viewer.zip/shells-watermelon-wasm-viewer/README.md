# Shell Ejector Lab — C++ → WebAssembly

A standalone 3D Canvas browser experiment: one Garry’s Mod-style shell emitter implemented with the **HL1/Source temporary-entity** idea, not VPhysics.

## What runs where

- `temp_gibs.cpp` — C++ simulation compiled to `temp_gibs.wasm`.
  - Structure-of-Arrays state for up to 4,096 entities.
  - A movable, elevated shell-ejector spawn origin, position integration, gravity, spin, simple map collision, reflection, bounce damping, lifetime/recycling.
  - A `explode_watermelon()` C++ effect path that emits rind, pulp, and seed fragments from the same movable source, then lets the one-shot burst expire.
  - The emitter source location is C++/wasm state (`set_emitter` / `emitter_x/y/z`); new shells are spawned at that location.
  - Eight axis-aligned 3D test-map walls plus world bounds.
- `app.js` — browser UI, orbit-camera/emitter input, perspective Canvas drawing, and typed-array views into exported wasm memory. It does not simulate effect physics.
- `index.html` — static UI.

## Run

Serve the directory rather than opening `index.html` directly, so the browser can fetch the wasm module:

```bash
cd temp-gibs-wasm
python3 -m http.server 8000 --bind 0.0.0.0
```

Then open `http://localhost:8000`.

## Build the wasm module

This uses a freestanding Clang build, without Emscripten. From this folder, the included script is the easiest rebuild path:

```bash
./build.sh
```

Equivalent explicit command:

```bash
clang++ --target=wasm32 -std=c++20 -O3 \
  -ffreestanding -fno-exceptions -fno-rtti -fno-stack-protector -nostdlib \
  temp_gibs.cpp \
  -Wl,--no-entry -Wl,--export-memory \
  -Wl,--export=reset -Wl,--export=step \
  -Wl,--export=set_gravity -Wl,--export=set_bounce -Wl,--export=set_emitter \
  -Wl,--export=emitter_x -Wl,--export=emitter_y -Wl,--export=emitter_z \
  -Wl,--export=explode_watermelon \
  -Wl,--export=entity_count -Wl,--export=collision_count \
  -Wl,--export=recycled_count -Wl,--export=max_entities \
  -Wl,--export=wall_count -Wl,--export=positions_x \
  -Wl,--export=positions_y -Wl,--export=positions_z \
  -Wl,--export=velocities_x -Wl,--export=velocities_y \
  -Wl,--export=spins -Wl,--export=active -Wl,--export=kinds -Wl,--export=wall_data \
  -Wl,--initial-memory=1048576 -Wl,--max-memory=1048576 \
  -Wl,--strip-all -o temp_gibs.wasm
```

## Relation to Source temporary entities

The core loop deliberately models the old temp-entity style:

```text
position += velocity × dt
trace / resolve against world geometry
reflect velocity around collision normal
apply damping
apply gravity
fade/recycle later
```

It does not model interactions between debris pieces. That limitation is intentional: it shows why shell casings and glass shards could look physical without each becoming a VPhysics object or a networked entity.
