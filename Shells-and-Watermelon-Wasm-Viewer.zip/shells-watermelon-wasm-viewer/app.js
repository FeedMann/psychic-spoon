// Browser responsibilities: control inputs, a view into exported wasm memory,
// and Canvas rendering. Simulation/spawn/randomness/collision stay in C++.
const canvas = document.querySelector('#sim');
const ctx = canvas.getContext('2d', { alpha: false });

const countInput = document.querySelector('#entityCount');
const gravityInput = document.querySelector('#gravity');
const bounceInput = document.querySelector('#bounce');
const countValue = document.querySelector('#entityCountValue');
const gravityValue = document.querySelector('#gravityValue');
const bounceValue = document.querySelector('#bounceValue');
const pauseButton = document.querySelector('#pause');
const resetButton = document.querySelector('#reset');
const watermelonButton = document.querySelector('#watermelon');
const wasmState = document.querySelector('#wasmState');
const statEntities = document.querySelector('#statEntities');
const statCollisions = document.querySelector('#statCollisions');
const statRecycled = document.querySelector('#statRecycled');
const statFrame = document.querySelector('#statFrame');

const WORLD = { left: -32, right: 32, bottom: -20, top: 20, ceiling: 16 };
let wasm;
let paused = false;
let lastTime = performance.now();
let frameAverage = 0;
let seed = 0x2A7F13C5;
let pixelWidth = 0;
let pixelHeight = 0;
let cameraYaw = 0.62;
let cameraPitch = 0.48;
let cameraDistance = 65;
let dragging = false;
let dragX = 0;
let dragY = 0;
const emitterKeys = new Set();
canvas.tabIndex = 0;

function formatNumber(value) {
  return Number(value).toLocaleString('en-US');
}

function setControlLabels() {
  countValue.textContent = formatNumber(countInput.value);
  gravityValue.textContent = `${Number(gravityInput.value).toFixed(0)} u/s²`;
  bounceValue.textContent = `${Number(bounceInput.value).toFixed(2)}`;
}

function nextSeed() {
  // C++ owns all effect random values after reset.
  seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
  return seed;
}

function resizeCanvas() {
  const rect = canvas.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  pixelWidth = Math.max(1, Math.floor(rect.width * dpr));
  pixelHeight = Math.max(1, Math.floor(rect.height * dpr));
  if (canvas.width !== pixelWidth || canvas.height !== pixelHeight) {
    canvas.width = pixelWidth;
    canvas.height = pixelHeight;
  }
}

function camera() {
  const target = { x: 0, y: 0, z: 5.2 };
  const cp = Math.cos(cameraPitch);
  const position = {
    x: target.x + cameraDistance * cp * Math.sin(cameraYaw),
    y: target.y - cameraDistance * cp * Math.cos(cameraYaw),
    z: target.z + cameraDistance * Math.sin(cameraPitch),
  };
  const fx = target.x - position.x;
  const fy = target.y - position.y;
  const fz = target.z - position.z;
  const fl = Math.hypot(fx, fy, fz);
  const forward = { x: fx / fl, y: fy / fl, z: fz / fl };
  // Normalize forward × worldUp. This makes an orbit camera without WebGL.
  const rl = Math.hypot(forward.y, forward.x);
  const right = { x: forward.y / rl, y: -forward.x / rl, z: 0 };
  const up = {
    x: right.y * forward.z,
    y: -right.x * forward.z,
    z: right.x * forward.y - right.y * forward.x,
  };
  return { position, forward, right, up, focal: pixelHeight * 1.02 };
}

function project(point, view) {
  const dx = point.x - view.position.x;
  const dy = point.y - view.position.y;
  const dz = point.z - view.position.z;
  const depth = dx * view.forward.x + dy * view.forward.y + dz * view.forward.z;
  if (depth <= 0.12) return null;
  const cameraX = dx * view.right.x + dy * view.right.y + dz * view.right.z;
  const cameraY = dx * view.up.x + dy * view.up.y + dz * view.up.z;
  const scale = view.focal / depth;
  return { x: pixelWidth * .5 + cameraX * scale, y: pixelHeight * .53 - cameraY * scale, depth, scale };
}

function polygon(projected, fill, stroke = null) {
  if (projected.some((p) => !p)) return;
  ctx.beginPath();
  ctx.moveTo(projected[0].x, projected[0].y);
  for (let i = 1; i < projected.length; i++) ctx.lineTo(projected[i].x, projected[i].y);
  ctx.closePath();
  if (fill) {
    ctx.fillStyle = fill;
    ctx.fill();
  }
  if (stroke) {
    ctx.strokeStyle = stroke;
    ctx.lineWidth = Math.max(1, pixelHeight / 680);
    ctx.stroke();
  }
}

function line3(a, b, view, style, width = 1) {
  const pa = project(a, view);
  const pb = project(b, view);
  if (!pa || !pb) return;
  ctx.strokeStyle = style;
  ctx.lineWidth = width;
  ctx.beginPath();
  ctx.moveTo(pa.x, pa.y);
  ctx.lineTo(pb.x, pb.y);
  ctx.stroke();
}

function drawFloor(view) {
  const corners = [
    project({ x: WORLD.left, y: WORLD.bottom, z: 0 }, view),
    project({ x: WORLD.right, y: WORLD.bottom, z: 0 }, view),
    project({ x: WORLD.right, y: WORLD.top, z: 0 }, view),
    project({ x: WORLD.left, y: WORLD.top, z: 0 }, view),
  ];
  polygon(corners, '#0c1c20');

  for (let x = -30; x <= 30; x += 5) {
    line3({ x, y: WORLD.bottom, z: .012 }, { x, y: WORLD.top, z: .012 }, view, 'rgba(107, 190, 176, .17)');
  }
  for (let y = -20; y <= 20; y += 5) {
    line3({ x: WORLD.left, y, z: .012 }, { x: WORLD.right, y, z: .012 }, view, 'rgba(107, 190, 176, .17)');
  }
  line3({ x: WORLD.left, y: WORLD.bottom, z: .015 }, { x: WORLD.right, y: WORLD.bottom, z: .015 }, view, 'rgba(199, 246, 233, .6)', 1.4);
  line3({ x: WORLD.right, y: WORLD.bottom, z: .015 }, { x: WORLD.right, y: WORLD.top, z: .015 }, view, 'rgba(199, 246, 233, .6)', 1.4);
  line3({ x: WORLD.right, y: WORLD.top, z: .015 }, { x: WORLD.left, y: WORLD.top, z: .015 }, view, 'rgba(199, 246, 233, .6)', 1.4);
  line3({ x: WORLD.left, y: WORLD.top, z: .015 }, { x: WORLD.left, y: WORLD.bottom, z: .015 }, view, 'rgba(199, 246, 233, .6)', 1.4);
}

function boxFaces(minX, maxX, minY, maxY, height, colors, view, objects) {
  const v = [
    { x: minX, y: minY, z: 0 }, { x: maxX, y: minY, z: 0 },
    { x: maxX, y: maxY, z: 0 }, { x: minX, y: maxY, z: 0 },
    { x: minX, y: minY, z: height }, { x: maxX, y: minY, z: height },
    { x: maxX, y: maxY, z: height }, { x: minX, y: maxY, z: height },
  ].map((point) => project(point, view));
  const faces = [
    [[4, 5, 6, 7], colors.top], [[0, 1, 5, 4], colors.front],
    [[1, 2, 6, 5], colors.side], [[2, 3, 7, 6], colors.back],
    [[3, 0, 4, 7], colors.side],
  ];
  for (const [indices, fill] of faces) {
    const points = indices.map((i) => v[i]);
    if (points.some((p) => !p)) continue;
    objects.push({
      depth: points.reduce((total, p) => total + p.depth, 0) / points.length,
      draw: () => polygon(points, fill, 'rgba(199, 245, 233, .22)'),
    });
  }
}

function drawShell(point, spin, kind) {
  const length = Math.min(10, Math.max(2.1, point.scale * .68));
  const width = Math.max(1.25, length * .32);
  const brass = kind === 0 ? '#eebd59' : (kind === 1 ? '#f7d16f' : '#bd8134');
  ctx.save();
  ctx.translate(point.x, point.y);
  ctx.rotate(spin);
  ctx.fillStyle = 'rgba(16, 12, 4, .36)';
  ctx.fillRect(-width * .36 + 1.4, -length * .5 + 1.7, width, length);
  ctx.fillStyle = brass;
  ctx.fillRect(-width * .5, -length * .5, width, length);
  ctx.fillStyle = 'rgba(255, 244, 191, .72)';
  ctx.fillRect(-width * .27, -length * .42, width * .25, length * .67);
  ctx.fillStyle = '#6e4215';
  ctx.fillRect(-width * .5, length * .26, width, length * .22);
  ctx.strokeStyle = 'rgba(70, 40, 9, .68)';
  ctx.lineWidth = Math.max(.55, length * .09);
  ctx.strokeRect(-width * .5, -length * .5, width, length);
  ctx.restore();
}

function drawWatermelonFragment(point, spin, kind) {
  const size = Math.min(12, Math.max(2.1, point.scale * (kind === 5 ? .27 : .64)));
  ctx.save();
  ctx.translate(point.x, point.y);
  ctx.rotate(spin);
  if (kind === 3) { // rind
    ctx.fillStyle = '#2e8a42';
    ctx.fillRect(-size * .52, -size * .42, size * 1.04, size * .84);
    ctx.fillStyle = '#93c94e';
    ctx.fillRect(-size * .13, -size * .42, size * .26, size * .84);
    ctx.strokeStyle = 'rgba(12, 52, 22, .85)';
    ctx.lineWidth = Math.max(.6, size * .11);
    ctx.strokeRect(-size * .52, -size * .42, size * 1.04, size * .84);
  } else if (kind === 4) { // pulp
    ctx.fillStyle = '#e9504c';
    ctx.beginPath();
    ctx.moveTo(-size * .57, size * .42);
    ctx.lineTo(-size * .12, -size * .56);
    ctx.lineTo(size * .56, size * .15);
    ctx.lineTo(size * .1, size * .56);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = 'rgba(255, 167, 132, .76)';
    ctx.fillRect(-size * .13, -size * .22, size * .23, size * .24);
  } else { // seed
    ctx.fillStyle = '#17120d';
    ctx.beginPath();
    ctx.ellipse(0, 0, size * .42, size * .25, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(241, 222, 166, .55)';
    ctx.fillRect(-size * .17, -size * .12, size * .14, size * .1);
  }
  ctx.restore();
}

function drawTempEntity(point, spin, kind) {
  if (kind < 3) drawShell(point, spin, kind);
  else drawWatermelonFragment(point, spin, kind);
}

function drawEmitter(emitter, view, objects) {
  boxFaces(emitter.x - .85, emitter.x + .85, emitter.y - .85, emitter.y + .85, Math.max(.75, emitter.z - 1.2),
    { top: '#b14b32', front: '#722f28', side: '#492425', back: '#5a2827' }, view, objects);
  const point = project({ x: emitter.x, y: emitter.y, z: emitter.z + .75 }, view);
  if (!point) return;
  objects.push({
    depth: point.depth - .02,
    draw: () => {
      ctx.save();
      ctx.translate(point.x, point.y);
      ctx.fillStyle = 'rgba(245, 184, 77, .22)';
      ctx.beginPath(); ctx.arc(0, 0, Math.min(16, point.scale * 1.05), 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#ffd884';
      ctx.beginPath(); ctx.arc(0, 0, Math.min(5, point.scale * .31), 0, Math.PI * 2); ctx.fill();
      ctx.restore();
    },
  });
}

function drawScene(state) {
  const view = camera();
  const sky = ctx.createLinearGradient(0, 0, 0, pixelHeight);
  sky.addColorStop(0, '#071215');
  sky.addColorStop(.56, '#10252a');
  sky.addColorStop(1, '#071012');
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, pixelWidth, pixelHeight);
  drawFloor(view);

  const objects = [];
  const wallColors = { top: '#31585a', front: '#17363a', side: '#10282d', back: '#143136' };
  for (let i = 0; i < state.walls.length; i += 5) {
    boxFaces(state.walls[i], state.walls[i + 1], state.walls[i + 2], state.walls[i + 3], state.walls[i + 4], wallColors, view, objects);
  }
  // Visual border walls match the C++ world bounds.
  const borderColors = { top: '#24494b', front: '#153136', side: '#10262b', back: '#132c30' };
  boxFaces(-32.5, -32, -20.5, 20.5, 8, borderColors, view, objects);
  boxFaces(32, 32.5, -20.5, 20.5, 8, borderColors, view, objects);
  boxFaces(-32.5, 32.5, -20.5, -20, 8, borderColors, view, objects);
  boxFaces(-32.5, 32.5, 20, 20.5, 8, borderColors, view, objects);
  drawEmitter(state.emitter, view, objects);

  // The state remains C++ owned; this loop only projects and draws it.
  for (let i = 0; i < state.count; i++) {
    if (!state.active[i]) continue;
    const point = project({ x: state.px[i], y: state.py[i], z: state.pz[i] }, view);
    if (!point || point.x < -14 || point.x > pixelWidth + 14 || point.y < -14 || point.y > pixelHeight + 14) continue;
    const spin = state.spin[i];
    const kind = state.kinds[i] % 3;
    objects.push({ depth: point.depth, draw: () => drawTempEntity(point, spin, kind) });
  }

  objects.sort((a, b) => b.depth - a.depth);
  for (const object of objects) object.draw();

  const marker = project({ x: state.emitter.x, y: state.emitter.y, z: state.emitter.z + 1.8 }, view);
  if (marker) {
    ctx.fillStyle = 'rgba(226, 245, 239, .9)';
    ctx.font = `${Math.max(10, Math.round(pixelHeight / 58))}px ui-monospace, SFMono-Regular, Menlo, monospace`;
    ctx.fillText(`SHELL EJECTOR  ${state.emitter.x.toFixed(1)}, ${state.emitter.y.toFixed(1)}, ${state.emitter.z.toFixed(1)}`, marker.x + 11, marker.y - 8);
  }
  ctx.fillStyle = 'rgba(222, 246, 239, .64)';
  ctx.font = `${Math.max(10, Math.round(pixelHeight / 61))}px ui-monospace, SFMono-Regular, Menlo, monospace`;
  ctx.fillText('WASD TEST CHAMBER · CLIENT-SIDE TEMP ENTITIES', 18, 25);
  ctx.fillStyle = 'rgba(222, 246, 239, .46)';
  ctx.fillText('DRAG: ORBIT · SCROLL: ZOOM · CLICK + WASD: MOVE · R/F: UP/DOWN', 18, 43);
}

function views() {
  const count = wasm.entity_count();
  const buffer = wasm.memory.buffer;
  return {
    count,
    emitter: { x: wasm.emitter_x(), y: wasm.emitter_y(), z: wasm.emitter_z() },
    px: new Float32Array(buffer, wasm.positions_x(), count),
    py: new Float32Array(buffer, wasm.positions_y(), count),
    pz: new Float32Array(buffer, wasm.positions_z(), count),
    spin: new Float32Array(buffer, wasm.spins(), count),
    active: new Uint32Array(buffer, wasm.active(), count),
    kinds: new Uint32Array(buffer, wasm.kinds(), count),
    walls: new Float32Array(buffer, wasm.wall_data(), wasm.wall_count() * 5),
  };
}

function updateStats(elapsed) {
  statEntities.textContent = formatNumber(wasm.entity_count());
  statCollisions.textContent = formatNumber(wasm.collision_count());
  statRecycled.textContent = formatNumber(wasm.recycled_count());
  frameAverage = frameAverage * .9 + elapsed * .1;
  statFrame.textContent = `${frameAverage.toFixed(2)} ms`;
}

function render(now) {
  const frameStart = performance.now();
  const delta = Math.min(.05, Math.max(0, (now - lastTime) / 1000));
  lastTime = now;
  updateEmitterInput(delta);
  if (!paused) wasm.step(delta);
  resizeCanvas();
  drawScene(views());
  updateStats(performance.now() - frameStart);
  requestAnimationFrame(render);
}

function reset() { wasm.reset(nextSeed(), Number(countInput.value)); }

function updateEmitterInput(dt) {
  if (!emitterKeys.size || !wasm) return;
  // Camera-relative ground movement plus explicit vertical controls. The
  // browser only forwards input; wasm retains the authoritative source point.
  const speed = emitterKeys.has('ShiftLeft') || emitterKeys.has('ShiftRight') ? 32 : 14;
  const forwardX = -Math.sin(cameraYaw);
  const forwardY = Math.cos(cameraYaw);
  const rightX = Math.cos(cameraYaw);
  const rightY = Math.sin(cameraYaw);
  let dx = 0, dy = 0, dz = 0;
  if (emitterKeys.has('KeyW')) { dx += forwardX; dy += forwardY; }
  if (emitterKeys.has('KeyS')) { dx -= forwardX; dy -= forwardY; }
  if (emitterKeys.has('KeyD')) { dx += rightX; dy += rightY; }
  if (emitterKeys.has('KeyA')) { dx -= rightX; dy -= rightY; }
  if (emitterKeys.has('KeyR')) dz += 1;
  if (emitterKeys.has('KeyF')) dz -= 1;
  const length = Math.hypot(dx, dy, dz);
  if (!length) return;
  const scale = (speed * dt) / length;
  wasm.set_emitter(
    wasm.emitter_x() + dx * scale,
    wasm.emitter_y() + dy * scale,
    wasm.emitter_z() + dz * scale,
  );
}

async function loadWasm() {
  try {
    let result;
    try {
      result = await WebAssembly.instantiateStreaming(fetch('./temp_gibs.wasm?v=3d-emitter-watermelon-4'), {});
    } catch {
      const response = await fetch('./temp_gibs.wasm?v=3d-emitter-watermelon-4');
      result = await WebAssembly.instantiate(await response.arrayBuffer(), {});
    }
    wasm = result.instance.exports;
    wasm.set_gravity(Number(gravityInput.value));
    wasm.set_bounce(Number(bounceInput.value));
    wasm.reset(seed, Number(countInput.value));
    wasmState.textContent = 'WebAssembly running';
    wasmState.classList.add('ready');
    requestAnimationFrame(render);
  } catch (error) {
    console.error(error);
    wasmState.textContent = 'WebAssembly failed to load';
    wasmState.classList.add('error');
  }
}

countInput.addEventListener('input', () => { setControlLabels(); if (wasm) reset(); });
gravityInput.addEventListener('input', () => { setControlLabels(); if (wasm) wasm.set_gravity(Number(gravityInput.value)); });
bounceInput.addEventListener('input', () => { setControlLabels(); if (wasm) wasm.set_bounce(Number(bounceInput.value)); });
pauseButton.addEventListener('click', () => {
  paused = !paused;
  pauseButton.textContent = paused ? 'Resume simulation' : 'Pause simulation';
});
resetButton.addEventListener('click', () => wasm && reset());
watermelonButton.addEventListener('click', () => wasm && wasm.explode_watermelon());
window.addEventListener('resize', resizeCanvas);
window.addEventListener('keydown', (event) => {
  if (document.activeElement !== canvas) return;
  if (['KeyW', 'KeyA', 'KeyS', 'KeyD', 'KeyR', 'KeyF', 'ShiftLeft', 'ShiftRight'].includes(event.code)) {
    event.preventDefault();
    emitterKeys.add(event.code);
  }
});
window.addEventListener('keyup', (event) => emitterKeys.delete(event.code));
window.addEventListener('blur', () => emitterKeys.clear());

canvas.addEventListener('pointerdown', (event) => {
  canvas.focus({ preventScroll: true });
  dragging = true; dragX = event.clientX; dragY = event.clientY;
  canvas.setPointerCapture(event.pointerId);
});
canvas.addEventListener('pointermove', (event) => {
  if (!dragging) return;
  cameraYaw += (event.clientX - dragX) * .008;
  cameraPitch = Math.max(.18, Math.min(1.08, cameraPitch + (event.clientY - dragY) * .006));
  dragX = event.clientX; dragY = event.clientY;
});
canvas.addEventListener('pointerup', () => { dragging = false; });
canvas.addEventListener('pointercancel', () => { dragging = false; });
canvas.addEventListener('wheel', (event) => {
  event.preventDefault();
  cameraDistance = Math.max(38, Math.min(100, cameraDistance + event.deltaY * .035));
}, { passive: false });

setControlLabels();
loadWasm();
