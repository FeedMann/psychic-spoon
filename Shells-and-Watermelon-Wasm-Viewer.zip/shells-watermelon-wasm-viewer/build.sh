#!/usr/bin/env bash
# Rebuild the standalone C++ -> WebAssembly module.
# Requires clang++ and lld with wasm32 target support.
set -euo pipefail

cd "$(dirname "$0")"

clang++ --target=wasm32 -std=c++20 -O3 \
  -ffreestanding -fno-exceptions -fno-rtti -fno-stack-protector -nostdlib \
  temp_gibs.cpp \
  -Wl,--no-entry -Wl,--export-memory \
  -Wl,--export=reset -Wl,--export=step \
  -Wl,--export=set_gravity -Wl,--export=set_bounce \
  -Wl,--export=set_emitter \
  -Wl,--export=emitter_x -Wl,--export=emitter_y -Wl,--export=emitter_z \
  -Wl,--export=explode_watermelon \
  -Wl,--export=entity_count -Wl,--export=collision_count \
  -Wl,--export=recycled_count -Wl,--export=max_entities \
  -Wl,--export=wall_count -Wl,--export=positions_x \
  -Wl,--export=positions_y -Wl,--export=positions_z \
  -Wl,--export=velocities_x -Wl,--export=velocities_y \
  -Wl,--export=spins -Wl,--export=active -Wl,--export=kinds \
  -Wl,--export=wall_data \
  -Wl,--initial-memory=1048576 -Wl,--max-memory=1048576 \
  -Wl,--strip-all \
  -o temp_gibs.wasm

echo "Built $(pwd)/temp_gibs.wasm"
